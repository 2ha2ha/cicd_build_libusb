#ifndef VERSION_H
#define VERSION_H

#define STLINK_VERSION       "1.8.0-91-g9446bf5-dirty"
#define STLINK_VERSION_MAJOR 1
#define STLINK_VERSION_MINOR 8
#define STLINK_VERSION_PATCH 0

#endif // VERSION_H
